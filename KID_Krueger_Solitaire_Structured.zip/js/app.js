(() => {

  const INSTALL_DISMISSED_KEY = "kids-install-guide-dismissed-v1";

  function isIOSDevice() {
    return /iphone|ipad|ipod/i.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  function isStandaloneMode() {
    return window.matchMedia("(display-mode: standalone)").matches ||
      window.navigator.standalone === true;
  }

  function showInstallGuide(force = false) {
    if (!isIOSDevice() || isStandaloneMode()) return;
    if (!force && localStorage.getItem(INSTALL_DISMISSED_KEY) === "yes") return;
    document.querySelector("#installOverlay").classList.add("show");
  }

  function hideInstallGuide(permanent = false) {
    document.querySelector("#installOverlay").classList.remove("show");
    if (permanent) localStorage.setItem(INSTALL_DISMISSED_KEY, "yes");
  }

  async function shareGame() {
    const shareData = {
      title: "Krueger Solitaire",
      text: "Play the free, ad-free Krueger Solitaire game.",
      url: window.location.href
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        if (error?.name !== "AbortError") {
          toast("Use Safari's Share button to send this game");
        }
      }
    } else {
      toast("Use your browser's Share menu to send this game");
    }
  }


  const SAVE_KEY = "krueger-solitaire-save-v02";
  const STATS_KEY = "krueger-solitaire-stats-v02";
  const THEME_KEY = "krueger-solitaire-theme-v02";
  const DRAW_KEY = "krueger-solitaire-draw-mode-v09";
  let drawMode = Number(localStorage.getItem(DRAW_KEY) || 1);
  let elapsedBeforeLoad = 0;

  function getStats() {
    try {
      return JSON.parse(localStorage.getItem(STATS_KEY)) || { games: 0, wins: 0, bestSeconds: null, bestMoves: null };
    } catch {
      return { games: 0, wins: 0, bestSeconds: null, bestMoves: null };
    }
  }

  function saveStats(stats) {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
    updateStatsPanel();
  updateDrawModeUI();
  }

  function updateStatsPanel() {
    const s = getStats();
    const format = (seconds) => {
      if (seconds == null) return "—";
      const m = Math.floor(seconds / 60);
      return `${m}:${String(seconds % 60).padStart(2, "0")}`;
    };
    document.querySelector("#statGames").textContent = s.games;
    document.querySelector("#statWins").textContent = s.wins;
    document.querySelector("#statBest").textContent = format(s.bestSeconds);
    document.querySelector("#statMoves").textContent = s.bestMoves ?? "—";
  }

  function saveCurrentGame() {
    if (!game) return;
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    localStorage.setItem(SAVE_KEY, JSON.stringify({ game, elapsed }));
  }

  function loadCurrentGame() {
    try {
      const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
      if (!saved?.game) return false;
      game = saved.game;
      elapsedBeforeLoad = saved.elapsed || 0;
      startTime = Date.now() - elapsedBeforeLoad * 1000;
      history = [];
      selected = null;
      render();
      return true;
    } catch {
      return false;
    }
  }

  function applyTheme(name) {
    const themes = {
      green: ["#0d6b3a", "#084b2a"],
      blue: ["#164a8a", "#082950"],
      burgundy: ["#721f35", "#3d0e1b"],
      black: ["#181818", "#050505"]
    };

    document.body.classList.remove("destination-theme");
    document.body.style.removeProperty("--destination-image");
    document.querySelector("#destinationBadge").style.display = "none";

    if (name === "palawan") {
      document.documentElement.style.setProperty("--felt", "#0f6f56");
      document.documentElement.style.setProperty("--felt-dark", "#073d31");
      document.body.classList.add("destination-theme");
      document.body.style.setProperty("--destination-image", "url('images/palawan.jpg')");
      document.body.style.backgroundImage =
        "linear-gradient(rgba(0,38,24,.58), rgba(0,38,24,.68)), url('images/palawan.jpg')";
      document.body.style.backgroundSize = "cover";
      document.body.style.backgroundPosition = "center";
      document.querySelector("#destinationBadge").style.display = "block";
    } else {
      const chosen = themes[name] || themes.green;
      document.documentElement.style.setProperty("--felt", chosen[0]);
      document.documentElement.style.setProperty("--felt-dark", chosen[1]);
      document.body.style.background =
        `radial-gradient(circle at 50% 15%, rgba(255,255,255,.08), transparent 35%), linear-gradient(180deg, ${chosen[0]}, ${chosen[1]})`;
    }

    localStorage.setItem(THEME_KEY, name);
    document.querySelectorAll(".theme-option").forEach(
      b => b.classList.toggle("active", b.dataset.theme === name)
    );
  }

  function showScreen(id) {
    document.querySelectorAll(".screen-overlay").forEach(el => el.classList.remove("show"));
    if (id) document.querySelector(`#${id}`).classList.add("show");
  }
  const suits = [
    { code: "S", symbol: "♠", color: "black" },
    { code: "H", symbol: "♥", color: "red" },
    { code: "D", symbol: "♦", color: "red" },
    { code: "C", symbol: "♣", color: "black" }
  ];
  const ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];

  let game;
  let selected = null;
  let history = [];
  let timerId = null;
  let startTime = null;

  let dragState = null;

  function selectedCardsFor(source, col, index) {
    if (source === "tableau") return game.tableau[col].slice(index);
    if (source === "waste") return [game.waste[index]];
    if (source === "foundation") return [game.foundations[col][index]];
    return [];
  }

  function createDragGhost(cards, startX, startY, sourceNode) {
    const ghost = document.createElement("div");
    ghost.className = "drag-ghost";
    const rect = sourceNode.getBoundingClientRect();
    const faceOffset = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--up-offset")) || 50;

    cards.forEach((card, i) => {
      const node = cardHTML(card, i + 1, i * faceOffset);
      node.style.position = "absolute";
      ghost.appendChild(node);
    });

    ghost.style.width = `${rect.width}px`;
    ghost.style.height = `${rect.height + Math.max(0, cards.length - 1) * faceOffset}px`;
    document.body.appendChild(ghost);

    return {
      node: ghost,
      offsetX: startX - rect.left,
      offsetY: startY - rect.top
    };
  }

  let dragFrame = null;
  let pendingDragPoint = null;

  function moveDragGhost(x, y) {
    if (!dragState?.ghost) return;
    pendingDragPoint = { x, y };

    if (dragFrame) return;

    dragFrame = requestAnimationFrame(() => {
      dragFrame = null;
      if (!dragState?.ghost || !pendingDragPoint) return;
      const point = pendingDragPoint;
      pendingDragPoint = null;

      dragState.ghost.node.style.transform =
        `translate3d(${point.x - dragState.ghost.offsetX}px, ${point.y - dragState.ghost.offsetY}px, 0)`;
    });
  }

  function clearDropTargets() {
    document.querySelectorAll(".drop-target").forEach(el => el.classList.remove("drop-target"));
  }

  function getDropTarget(x, y) {
    if (!dragState) return null;
    const ghost = dragState.ghost?.node;
    if (ghost) ghost.style.display = "none";
    const el = document.elementFromPoint(x, y);
    if (ghost) ghost.style.display = "";

    if (!el) return null;

    const foundation = el.closest("[data-foundation]");
    if (foundation) {
      const suit = foundation.dataset.foundation;
      if (dragState.cards.length === 1 && canPlaceOnFoundation(dragState.cards[0], suit)) {
        return { type: "foundation", suit, el: foundation };
      }
    }

    const column = el.closest(".column");
    if (column) {
      const col = Number(column.dataset.col);
      if (dragState.source === "tableau" && dragState.col === col) return null;
      const pile = game.tableau[col];
      const target = pile[pile.length - 1];
      if (canPlaceOnTableau(dragState.cards[0], target)) {
        return { type: "tableau", col, el: column };
      }
    }
    return null;
  }

  let targetFrame = null;
  let pendingTargetPoint = null;

  function updateDropTarget(x, y) {
    pendingTargetPoint = { x, y };
    if (targetFrame) return;

    targetFrame = requestAnimationFrame(() => {
      targetFrame = null;
      if (!dragState || !pendingTargetPoint) return;
      const point = pendingTargetPoint;
      pendingTargetPoint = null;

      clearDropTargets();
      const target = getDropTarget(point.x, point.y);
      dragState.target = target;
      if (target) target.el.classList.add("drop-target");
    });
  }

  function beginCardDrag(event, source, col, index, cardNode) {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    let card;
    if (source === "tableau") card = game.tableau[col][index];
    if (source === "waste") card = game.waste[index];
    if (source === "foundation") card = game.foundations[col][index];
    if (!card?.faceUp) return;

    const cards = selectedCardsFor(source, col, index);
    if (!cards.length) return;

    dragState = {
      pointerId: event.pointerId,
      source,
      col,
      index,
      cards,
      startX: event.clientX,
      startY: event.clientY,
      currentX: event.clientX,
      currentY: event.clientY,
      dragging: false,
      sourceNodes: []
    };

    cardNode.setPointerCapture?.(event.pointerId);
  }

  function moveCardDrag(event) {
    if (!dragState || event.pointerId !== dragState.pointerId) return;
    dragState.currentX = event.clientX;
    dragState.currentY = event.clientY;

    const distance = Math.hypot(
      dragState.currentX - dragState.startX,
      dragState.currentY - dragState.startY
    );

    if (!dragState.dragging && distance > 6) {
      dragState.dragging = true;
      dragState.ghost = createDragGhost(
        dragState.cards,
        dragState.startX,
        dragState.startY,
        event.currentTarget
      );

      dragState.sourceNodes = [...document.querySelectorAll(
        dragState.cards.map(c => `[data-id="${c.id}"]`).join(",")
      )];
      dragState.sourceNodes.forEach(node => node.classList.add("drag-source"));
      document.body.classList.add("dragging");
      selected = null;
    }

    if (dragState.dragging) {
      event.preventDefault();
      moveDragGhost(event.clientX, event.clientY);
      updateDropTarget(event.clientX, event.clientY);
    }
  }

  function finishCardDrag(event) {
    if (!dragState || event.pointerId !== dragState.pointerId) return;

    if (dragState.dragging && dragState.target) {
      selected = {
        source: dragState.source,
        col: dragState.col,
        index: dragState.index,
        card: dragState.cards[0]
      };

      if (dragState.target.type === "tableau") {
        tryMoveToTableau(dragState.target.col);
      } else {
        tryMoveToFoundation(dragState.target.suit);
      }
    } else if (!dragState.dragging) {
      selectCard(dragState.source, dragState.col, dragState.index);
    }

    if (dragFrame) cancelAnimationFrame(dragFrame);
    if (targetFrame) cancelAnimationFrame(targetFrame);
    dragFrame = null;
    targetFrame = null;
    pendingDragPoint = null;
    pendingTargetPoint = null;
    dragState.sourceNodes?.forEach(node => node.classList.remove("drag-source"));
    dragState.ghost?.node.remove();
    clearDropTargets();
    document.body.classList.remove("dragging");
    dragState = null;
  }

  function cancelCardDrag() {
    if (!dragState) return;
    dragState.sourceNodes?.forEach(node => node.classList.remove("drag-source"));
    dragState.ghost?.node.remove();
    clearDropTargets();
    document.body.classList.remove("dragging");
    dragState = null;
  }

  function attachDragHandlers(node, source, col, index) {
    node.addEventListener("pointerdown", e => beginCardDrag(e, source, col, index, node));
    node.addEventListener("pointermove", moveCardDrag);
    node.addEventListener("pointerup", finishCardDrag);
    node.addEventListener("pointercancel", cancelCardDrag);
  }

  const $ = (s) => document.querySelector(s);
  const tableauEl = $("#tableau");
  const stockEl = $("#stock");
  const wasteEl = $("#waste");
  const msgEl = $("#message");

  function freshDeck() {
    let deck = [];
    for (const suit of suits) {
      ranks.forEach((rank, i) => deck.push({
        id: suit.code + rank,
        suit: suit.code,
        symbol: suit.symbol,
        color: suit.color,
        rank,
        value: i + 1,
        faceUp: false
      }));
    }
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  }

  function newGame(countGame = true) {
    clearInterval(timerId);
    if (countGame) {
      const stats = getStats();
      stats.games++;
      saveStats(stats);
    }
    clearInterval(timerId);
    startTime = Date.now();
    timerId = setInterval(updateTime, 1000);
    const deck = freshDeck();
    const tableau = Array.from({ length: 7 }, () => []);
    for (let col = 0; col < 7; col++) {
      for (let row = 0; row <= col; row++) {
        const c = deck.pop();
        c.faceUp = row === col;
        tableau[col].push(c);
      }
    }
    game = {
      stock: deck,
      waste: [],
      tableau,
      foundations: { S: [], H: [], D: [], C: [] },
      moves: 0,
      stockPasses: 0
    };
    selected = null;
    history = [];
    $("#win").classList.remove("show");
    render();
  }

  function snapshot() {
    history.push(JSON.stringify(game));
    if (history.length > 100) history.shift();
  }

  function undo() {
    if (!history.length) return toast("Nothing to undo");
    game = JSON.parse(history.pop());
    selected = null;
    render();
  }

  function updateTime() {
    if (!startTime) return;
    const sec = Math.floor((Date.now() - startTime) / 1000);
    const m = Math.floor(sec / 60);
    const s = String(sec % 60).padStart(2, "0");
    $("#time").textContent = `${m}:${s}`;
  }

  function cardHTML(card, z = 1, top = 0) {
    const div = document.createElement("div");
    const isFace = card.faceUp && ["J","Q","K"].includes(card.rank);
    const isAce = card.faceUp && card.rank === "A";
    div.className = `card ${card.color === "red" ? "red" : ""} ${card.faceUp ? "" : "face-down"} ${isFace ? "face-card" : ""} ${isAce ? "ace-card" : ""}`;
    div.dataset.id = card.id;
    div.style.zIndex = z;
    div.style.top = `${top}px`;

    if (card.faceUp) {
      let centerContent = "";

      if (isFace) {
        centerContent = `<div class="center"><span>${card.rank}</span><span style="font-size:.72em">${card.symbol}</span></div>`;
      } else if (card.rank === "A") {
        centerContent = `<div class="center">${card.symbol}</div>`;
      } else {
        const count = Math.min(card.value, 10);
        const pips = Array.from({ length: count }, (_, i) =>
          `<span class="pip ${i >= Math.ceil(count / 2) ? "flip" : ""}">${card.symbol}</span>`
        ).join("");
        centerContent = `<div class="pip-grid ${count === 1 ? "single" : ""}">${pips}</div>`;
      }

      div.innerHTML = `
        <div class="island-mark"></div>
        <div class="corner"><span>${card.rank}</span><span class="suit-small">${card.symbol}</span></div>
        ${centerContent}
        <div class="corner bottom"><span>${card.rank}</span><span class="suit-small">${card.symbol}</span></div>`;
    }
    return div;
  }

  function render() {
    $("#moves").textContent = `Moves: ${game.moves}`;
    document.querySelectorAll(".foundation").forEach(el => {
      const suit = el.dataset.foundation;
      el.innerHTML = "";
      const pile = game.foundations[suit];
      if (pile.length) {
        const card = pile[pile.length - 1];
        const node = cardHTML(card);
        attachDragHandlers(node, "foundation", suit, pile.length - 1);
        el.appendChild(node);
      }
    });

    stockEl.innerHTML = "";
    stockEl.textContent = game.stock.length ? "" : "↻";
    if (game.stock.length) {
      const back = cardHTML({ id:"stock", faceUp:false });
      back.addEventListener("click", drawStock);
      stockEl.appendChild(back);
    } else {
      stockEl.onclick = recycleStock;
    }

    wasteEl.innerHTML = "";
    if (game.waste.length) {
      const card = game.waste[game.waste.length - 1];
      const node = cardHTML(card);
      attachDragHandlers(node, "waste", null, game.waste.length - 1);
      wasteEl.appendChild(node);
    }

    tableauEl.innerHTML = "";
    game.tableau.forEach((col, ci) => {
      const colEl = document.createElement("div");
      colEl.className = `column ${col.length ? "" : "empty"}`;
      colEl.dataset.col = ci;
      colEl.addEventListener("click", (e) => {
        if (e.target === colEl) tryMoveToTableau(ci);
      });

      let top = 0;
      col.forEach((card, ri) => {
        const node = cardHTML(card, ri + 1, top);
        if (selected && selected.source === "tableau" && selected.col === ci && ri >= selected.index) {
          node.classList.add("selected");
        }
        if (!card.faceUp) {
          node.addEventListener("click", (e) => {
            e.stopPropagation();
            if (ri === col.length - 1) {
              snapshot();
              card.faceUp = true;
              game.moves++;
              render();
            }
          });
        } else {
          attachDragHandlers(node, "tableau", ci, ri);
        }
        colEl.appendChild(node);
        top += card.faceUp ? parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--up-offset")) || 42
                           : parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--down-offset")) || 28;
      });
      tableauEl.appendChild(colEl);
    });

    if (selected) {
      document.querySelectorAll(`[data-id="${selected.card.id}"]`).forEach(el => el.classList.add("selected"));
    }

    requestAnimationFrame(() => {
      document.querySelectorAll(".card").forEach(card => {
        card.classList.add("snap-in");
        setTimeout(() => card.classList.remove("snap-in"), 180);
      });
    });

    checkWin();
    saveCurrentGame();
  }

  function drawStock() {
    if (!game.stock.length) return recycleStock();
    snapshot();

    const count = Math.min(drawMode, game.stock.length);
    for (let i = 0; i < count; i++) {
      const c = game.stock.pop();
      c.faceUp = true;
      game.waste.push(c);
    }

    game.moves++;
    selected = null;
    render();
  }

  function recycleStock() {
    if (!game.waste.length) return toast("No cards to recycle");
    snapshot();
    game.stock = game.waste.reverse().map(c => ({...c, faceUp:false}));
    game.waste = [];
    game.stockPasses = (game.stockPasses || 0) + 1;
    game.moves++;
    selected = null;
    render();
  }

  function selectCard(source, col, index) {
    let card;
    if (source === "waste") card = game.waste[index];
    if (source === "foundation") card = game.foundations[col][index];
    if (source === "tableau") card = game.tableau[col][index];

    if (!card || !card.faceUp) return;

    if (selected && selected.card.id === card.id) {
      if (!tryAutoFoundation()) {
        selected = null;
        render();
      }
      return;
    }

    // When a card is already selected, tapping the top card of another
    // tableau column attempts to move the selection there.
    if (selected && source === "tableau") {
      const targetPile = game.tableau[col];
      if (index === targetPile.length - 1 && !(selected.source === "tableau" && selected.col === col)) {
        const moving = selected.source === "tableau"
          ? game.tableau[selected.col].slice(selected.index)
          : [selected.card];
        if (canPlaceOnTableau(moving[0], card)) {
          tryMoveToTableau(col);
          return;
        }
      }
    }

    selected = { source, col, index, card };
    showTapGuide();
    render();
  }

  function isRed(card) { return card.color === "red"; }

  function canPlaceOnTableau(card, target) {
    if (!target) return card.value === 13;
    return target.faceUp && isRed(card) !== isRed(target) && target.value === card.value + 1;
  }

  function canPlaceOnFoundation(card, suit) {
    if (card.suit !== suit) return false;
    const pile = game.foundations[suit];
    return card.value === pile.length + 1;
  }

  function removeSelected() {
    if (selected.source === "waste") return [game.waste.pop()];
    if (selected.source === "foundation") return [game.foundations[selected.col].pop()];
    if (selected.source === "tableau") {
      return game.tableau[selected.col].splice(selected.index);
    }
    return [];
  }

  function revealTop(col) {
    const pile = game.tableau[col];
    if (pile.length && !pile[pile.length - 1].faceUp) {
      pile[pile.length - 1].faceUp = true;
    }
  }

  function tryMoveToTableau(targetCol) {
    if (!selected) return;
    const moving = selected.source === "tableau"
      ? game.tableau[selected.col].slice(selected.index)
      : [selected.card];
    const targetPile = game.tableau[targetCol];
    const target = targetPile[targetPile.length - 1];

    if (selected.source === "tableau" && selected.col === targetCol) return;

    if (canPlaceOnTableau(moving[0], target)) {
      snapshot();
      const fromCol = selected.source === "tableau" ? selected.col : null;
      targetPile.push(...removeSelected());
      if (fromCol !== null) revealTop(fromCol);
      game.moves++;
      selected = null;
      render();
    } else {
      toast("That card cannot go there");
    }
  }

  function tryMoveToFoundation(suit) {
    if (!selected) return;
    if (selected.source === "tableau" && selected.index !== game.tableau[selected.col].length - 1) {
      return toast("Only the top card can move to a foundation");
    }
    if (!canPlaceOnFoundation(selected.card, suit)) return toast("That card cannot go there");

    snapshot();
    const fromCol = selected.source === "tableau" ? selected.col : null;
    const [card] = removeSelected();
    game.foundations[suit].push(card);
    if (fromCol !== null) revealTop(fromCol);
    game.moves++;
    selected = null;
    render();
  }

  function tryAutoFoundation() {
    if (!selected) return false;
    if (selected.source === "tableau" && selected.index !== game.tableau[selected.col].length - 1) return false;
    const suit = selected.card.suit;
    if (!canPlaceOnFoundation(selected.card, suit)) return false;
    tryMoveToFoundation(suit);
    return true;
  }

  function toast(text) {
    msgEl.textContent = text;
    msgEl.classList.add("show");
    setTimeout(() => msgEl.classList.remove("show"), 1200);
  }

  function showTapGuide() {
    const el = document.querySelector("#tapGuide");
    el.classList.add("show");
    clearTimeout(showTapGuide.timer);
    showTapGuide.timer = setTimeout(() => el.classList.remove("show"), 1100);
  }


  function updateDrawModeUI() {
    $("#draw1Btn").classList.toggle("active", drawMode === 1);
    $("#draw3Btn").classList.toggle("active", drawMode === 3);
  }

  function setDrawMode(mode) {
    drawMode = mode;
    localStorage.setItem(DRAW_KEY, String(mode));
    updateDrawModeUI();
    toast(`Draw ${mode} enabled`);
  }

  function clearHints() {
    document.querySelectorAll(".hint-target").forEach(el => el.classList.remove("hint-target"));
  }

  function highlightCard(cardId) {
    clearHints();
    const el = document.querySelector(`[data-id="${cardId}"]`);
    if (!el) return false;
    el.classList.add("hint-target");
    setTimeout(() => el.classList.remove("hint-target"), 2600);
    return true;
  }

  function findHint() {
    clearHints();

    // 1. Prefer safe moves to foundations.
    const wasteTop = game.waste[game.waste.length - 1];
    if (wasteTop && canPlaceOnFoundation(wasteTop, wasteTop.suit)) {
      highlightCard(wasteTop.id);
      return toast(`${wasteTop.rank}${wasteTop.symbol} can move to its foundation`);
    }

    for (let col = 0; col < game.tableau.length; col++) {
      const pile = game.tableau[col];
      const card = pile[pile.length - 1];
      if (card?.faceUp && canPlaceOnFoundation(card, card.suit)) {
        highlightCard(card.id);
        return toast(`${card.rank}${card.symbol} can move to its foundation`);
      }
    }

    // 2. Look for tableau moves that reveal a facedown card.
    for (let from = 0; from < game.tableau.length; from++) {
      const source = game.tableau[from];
      for (let i = 0; i < source.length; i++) {
        const card = source[i];
        if (!card.faceUp) continue;

        for (let to = 0; to < game.tableau.length; to++) {
          if (from === to) continue;
          const targetPile = game.tableau[to];
          const target = targetPile[targetPile.length - 1];

          if (canPlaceOnTableau(card, target)) {
            highlightCard(card.id);
            return toast(`Move ${card.rank}${card.symbol} to another column`);
          }
        }
      }
    }

    // 3. Look for a waste-to-tableau move.
    if (wasteTop) {
      for (let to = 0; to < game.tableau.length; to++) {
        const targetPile = game.tableau[to];
        const target = targetPile[targetPile.length - 1];
        if (canPlaceOnTableau(wasteTop, target)) {
          highlightCard(wasteTop.id);
          return toast(`Move ${wasteTop.rank}${wasteTop.symbol} to the tableau`);
        }
      }
    }

    // 4. Suggest drawing or recycling.
    if (game.stock.length) {
      const stockCard = stockEl.querySelector(".card");
      if (stockCard) {
        stockCard.classList.add("hint-target");
        setTimeout(() => stockCard.classList.remove("hint-target"), 2600);
      }
      return toast(`Draw ${drawMode} card${drawMode === 1 ? "" : "s"} from the stock`);
    }

    if (game.waste.length) {
      stockEl.classList.add("hint-target");
      setTimeout(() => stockEl.classList.remove("hint-target"), 2600);
      return toast("Recycle the waste pile");
    }

    toast("No obvious move found");
  }

  function checkWin() {
    const total = Object.values(game.foundations).reduce((a, p) => a + p.length, 0);
    if (total === 52) {
      clearInterval(timerId);
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const stats = getStats();
      if (!game.winRecorded) {
        stats.wins++;
        stats.bestSeconds = stats.bestSeconds == null ? elapsed : Math.min(stats.bestSeconds, elapsed);
        stats.bestMoves = stats.bestMoves == null ? game.moves : Math.min(stats.bestMoves, game.moves);
        game.winRecorded = true;
        saveStats(stats);
        saveCurrentGame();
      }
      $("#winStats").textContent = `Finished in ${$("#time").textContent} with ${game.moves} moves.`;
      $("#win").classList.add("show");
    }
  }

  document.querySelectorAll(".foundation").forEach(el => {
    el.addEventListener("click", (e) => {
      if (e.target === el) tryMoveToFoundation(el.dataset.foundation);
    });
  });

  $("#shareGameBtn").addEventListener("click", shareGame);
  $("#installDoneBtn").addEventListener("click", () => hideInstallGuide(true));
  $("#installLaterBtn").addEventListener("click", () => hideInstallGuide(false));
  $("#installHelpBtn").addEventListener("click", () => showInstallGuide(true));

  if (isIOSDevice() && !isStandaloneMode()) {
    $("#installHelpBtn").classList.add("show");
    setTimeout(() => showInstallGuide(false), 850);
  }

  $("#newBtn").addEventListener("click", () => newGame(true));
  $("#undoBtn").addEventListener("click", undo);
  $("#hintBtn").addEventListener("click", findHint);
  $("#draw1Btn").addEventListener("click", () => setDrawMode(1));
  $("#draw3Btn").addEventListener("click", () => setDrawMode(3));
  $("#playAgain").addEventListener("click", () => newGame(true));
  $("#homeBtn").addEventListener("click", () => showScreen("homeScreen"));

  $("#continueBtn").addEventListener("click", () => {
    if (!game && !loadCurrentGame()) newGame(true);
    showScreen(null);
  });

  $("#freshGameBtn").addEventListener("click", () => {
    newGame(true);
    showScreen(null);
  });

  $("#statsBtn").addEventListener("click", () => {
    updateStatsPanel();
    showScreen("statsScreen");
  });

  $("#settingsBtn").addEventListener("click", () => showScreen("settingsScreen"));

  document.querySelectorAll("[data-close]").forEach(btn => {
    btn.addEventListener("click", () => showScreen("homeScreen"));
  });

  document.querySelectorAll(".theme-option").forEach(btn => {
    btn.addEventListener("click", () => applyTheme(btn.dataset.theme));
  });

  $("#resetStatsBtn").addEventListener("click", () => {
    if (confirm("Reset all Krueger Solitaire statistics?")) {
      localStorage.removeItem(STATS_KEY);
      updateStatsPanel();
    }
  });

  applyTheme(localStorage.getItem(THEME_KEY) || "palawan");
  updateStatsPanel();

  clearInterval(timerId);
  startTime = Date.now();
  timerId = setInterval(updateTime, 1000);
  if (!loadCurrentGame()) {
    newGame(false);
  }
})();
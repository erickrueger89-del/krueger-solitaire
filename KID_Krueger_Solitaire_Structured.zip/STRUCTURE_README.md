# Krueger Solitaire — Structured Build

This is the first multi-file KID's project layout.

## Files

- index.html — page structure
- css/main.css — all styling
- js/app.js — all game logic
- images/palawan.jpg — Palawan background

## Future Structure

Additional folders can be added later:

- images/cardbacks/
- images/themes/
- audio/
- data/
- js/modules/

## Publishing

Upload the folder contents to the root of the GitHub repository.
GitHub Pages will continue using index.html automatically.
